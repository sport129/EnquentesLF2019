-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 16-Jan-2019 às 19:06
-- Versão do servidor: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_enquetes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(3, '2014_10_12_000000_create_users_table', 1),
(4, '2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_categoria`
--

CREATE TABLE `tb_categoria` (
  `id_categoria` int(11) NOT NULL,
  `categoria` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_comentario`
--

CREATE TABLE `tb_comentario` (
  `id_comentario` int(11) NOT NULL,
  `fk_sttsee` int(11) NOT NULL,
  `fk_categoria` int(11) NOT NULL,
  `comentario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_disciplina`
--

CREATE TABLE `tb_disciplina` (
  `id_disciplina` int(11) NOT NULL,
  `disciplina` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_disciplina`
--

INSERT INTO `tb_disciplina` (`id_disciplina`, `disciplina`) VALUES
(1, 'Disciplina Teste 1'),
(2, 'Disciplina Teste 2'),
(3, 'Disciplina Teste 3'),
(4, 'Disciplina Teste 4');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_ensino`
--

CREATE TABLE `tb_ensino` (
  `id_ensino` int(11) NOT NULL,
  `Ensino` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_ensino`
--

INSERT INTO `tb_ensino` (`id_ensino`, `Ensino`) VALUES
(2, 'Fundamental'),
(3, 'Médio'),
(4, 'Pré-Universitário');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_perguntas`
--

CREATE TABLE `tb_perguntas` (
  `id_perguntas` int(11) NOT NULL,
  `fk_categories` int(11) NOT NULL,
  `fk_tpensino` int(11) NOT NULL,
  `perguta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `viewpergunta` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_professor`
--

CREATE TABLE `tb_professor` (
  `id_professor` int(11) NOT NULL,
  `professor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_prof_dis_turm`
--

CREATE TABLE `tb_prof_dis_turm` (
  `id_pdt` int(11) NOT NULL,
  `fk_disci` int(11) NOT NULL,
  `fk_prof` int(11) NOT NULL,
  `fk_sttse` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_respostaprofessor`
--

CREATE TABLE `tb_respostaprofessor` (
  `id_resprof` int(11) NOT NULL,
  `fk_pdt` int(11) NOT NULL,
  `otimo` int(11) NOT NULL,
  `bom` int(11) NOT NULL,
  `regular` int(11) NOT NULL,
  `insuficiente` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_respostas`
--

CREATE TABLE `tb_respostas` (
  `id_resposta` int(11) NOT NULL,
  `fk_sttseresp` int(11) NOT NULL,
  `fk_pergunta` int(11) NOT NULL,
  `otimo` int(11) NOT NULL,
  `bom` int(11) NOT NULL,
  `regular` int(11) NOT NULL,
  `insuficiente` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_sedes`
--

CREATE TABLE `tb_sedes` (
  `id_sedes` int(11) NOT NULL,
  `Sede` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_sedes`
--

INSERT INTO `tb_sedes` (`id_sedes`, `Sede`) VALUES
(4, 'Central'),
(5, 'Montese'),
(6, 'Parangaba');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_sede_turma_turno_serie_ensino`
--

CREATE TABLE `tb_sede_turma_turno_serie_ensino` (
  `id_sttse` int(11) NOT NULL,
  `fk_sede` int(11) NOT NULL,
  `fk_turno` int(11) NOT NULL,
  `fk_serie` int(11) NOT NULL,
  `fk_turma` int(11) NOT NULL,
  `fk_ensino` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_sede_turma_turno_serie_ensino`
--

INSERT INTO `tb_sede_turma_turno_serie_ensino` (`id_sttse`, `fk_sede`, `fk_turno`, `fk_serie`, `fk_turma`, `fk_ensino`) VALUES
(1, 4, 2, 2, 2, 2),
(2, 4, 2, 2, 2, 2),
(3, 4, 3, 2, 2, 2),
(4, 4, 2, 2, 2, 2),
(5, 4, 2, 2, 2, 2),
(6, 4, 2, 2, 2, 2),
(7, 4, 2, 2, 2, 2),
(8, 4, 2, 2, 2, 2),
(9, 4, 2, 2, 2, 2),
(10, 4, 2, 2, 2, 2),
(11, 4, 2, 2, 2, 2),
(12, 4, 2, 2, 2, 2),
(13, 4, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_series`
--

CREATE TABLE `tb_series` (
  `id_serie` int(11) NOT NULL,
  `Serie` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_series`
--

INSERT INTO `tb_series` (`id_serie`, `Serie`) VALUES
(2, '6º Ano'),
(3, '7º Ano'),
(4, '8º Ano'),
(5, '9º Ano'),
(6, '1º Serie'),
(7, '2º Serie'),
(8, '1º Serie Telf'),
(9, '2º Serie Telf'),
(10, '3º Serie'),
(11, '3º Serie Telf'),
(12, 'Pré-Enem');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_tipousers`
--

CREATE TABLE `tb_tipousers` (
  `id_tipousers` int(11) NOT NULL,
  `tipouser` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_tipousers`
--

INSERT INTO `tb_tipousers` (`id_tipousers`, `tipouser`) VALUES
(1, 'Administrador'),
(2, 'Coordenador'),
(3, 'Direção');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turma`
--

CREATE TABLE `tb_turma` (
  `id_turma` int(11) NOT NULL,
  `Turma` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_turma`
--

INSERT INTO `tb_turma` (`id_turma`, `Turma`) VALUES
(2, '16m01'),
(3, '16m02'),
(4, '17m01'),
(5, '17m02'),
(6, '18m01'),
(7, '18m02'),
(8, '19m01'),
(9, '21m01'),
(10, '21m02'),
(11, '22m01'),
(12, '22m02'),
(14, '16t01'),
(15, '17t01'),
(16, '18t01'),
(17, '19t01'),
(18, '21t01'),
(19, '22t01'),
(20, '23m01'),
(21, '23m02'),
(22, '23m03'),
(23, '33m01'),
(24, '23t01'),
(25, '72m01'),
(26, 'telf');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_turno`
--

CREATE TABLE `tb_turno` (
  `id_turno` int(11) NOT NULL,
  `Turno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `tb_turno`
--

INSERT INTO `tb_turno` (`id_turno`, `Turno`) VALUES
(2, 'Manhã'),
(3, 'Tarde');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tipoUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `tipoUser`) VALUES
(1, 'admin', 'admin3312@hotmail.com', '$2y$10$Gx.Dj/mv2ak5yqQ5vlRiaO79L1EjgLRTaNDX3WUZC1BJ3hm6gferu', 'WxXbT0rBu5brINsfOvfSE8YWvMHdZds0X8ES0NesW1s0F7VUSP2HfrSw7j8K', '2019-01-08 20:41:08', '2019-01-16 19:17:35', 1),
(2, 'admin2', 'admin2@hotmail.com', '$2y$10$hI8iLCxyGNjYYmRxjHFBXeiQAtTErOlMcdGpQ6XnIV18BQlLoa6Um', 'YlxqpUnhMeKwbH7POsrMhupZTASXC1lh4NCLQ1pAHtH54wStOXa2KJdXmKwJ', '2019-01-08 21:08:45', '2019-01-08 21:08:45', 1),
(4, 'admin3', 'admin3@hotmail.com', '$2y$10$.FEeJlicn8X09uuIi.8Qy.zBL9t2aHj5CYWo3DNWSwRdZBsrwfvF2', NULL, '2019-01-16 19:21:58', '2019-01-16 19:21:58', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indexes for table `tb_comentario`
--
ALTER TABLE `tb_comentario`
  ADD PRIMARY KEY (`id_comentario`),
  ADD KEY `fk_sttsee` (`fk_sttsee`),
  ADD KEY `fk_categoria` (`fk_categoria`);

--
-- Indexes for table `tb_disciplina`
--
ALTER TABLE `tb_disciplina`
  ADD PRIMARY KEY (`id_disciplina`);

--
-- Indexes for table `tb_ensino`
--
ALTER TABLE `tb_ensino`
  ADD PRIMARY KEY (`id_ensino`);

--
-- Indexes for table `tb_perguntas`
--
ALTER TABLE `tb_perguntas`
  ADD PRIMARY KEY (`id_perguntas`),
  ADD KEY `fk_categories` (`fk_categories`),
  ADD KEY `fk_tpensino` (`fk_tpensino`);

--
-- Indexes for table `tb_professor`
--
ALTER TABLE `tb_professor`
  ADD PRIMARY KEY (`id_professor`);

--
-- Indexes for table `tb_prof_dis_turm`
--
ALTER TABLE `tb_prof_dis_turm`
  ADD PRIMARY KEY (`id_pdt`),
  ADD KEY `fk_disci` (`fk_disci`),
  ADD KEY `fk_prof` (`fk_prof`),
  ADD KEY `fk_sttse` (`fk_sttse`);

--
-- Indexes for table `tb_respostaprofessor`
--
ALTER TABLE `tb_respostaprofessor`
  ADD PRIMARY KEY (`id_resprof`);

--
-- Indexes for table `tb_respostas`
--
ALTER TABLE `tb_respostas`
  ADD PRIMARY KEY (`id_resposta`),
  ADD KEY `fk_sttseresp` (`fk_sttseresp`),
  ADD KEY `fk_pergunta` (`fk_pergunta`);

--
-- Indexes for table `tb_sedes`
--
ALTER TABLE `tb_sedes`
  ADD PRIMARY KEY (`id_sedes`);

--
-- Indexes for table `tb_sede_turma_turno_serie_ensino`
--
ALTER TABLE `tb_sede_turma_turno_serie_ensino`
  ADD PRIMARY KEY (`id_sttse`),
  ADD KEY `fk_sede` (`fk_sede`),
  ADD KEY `fk_turno` (`fk_turno`),
  ADD KEY `fk_serie` (`fk_serie`),
  ADD KEY `fk_turma` (`fk_turma`),
  ADD KEY `fk_ensino` (`fk_ensino`);

--
-- Indexes for table `tb_series`
--
ALTER TABLE `tb_series`
  ADD PRIMARY KEY (`id_serie`);

--
-- Indexes for table `tb_tipousers`
--
ALTER TABLE `tb_tipousers`
  ADD PRIMARY KEY (`id_tipousers`);

--
-- Indexes for table `tb_turma`
--
ALTER TABLE `tb_turma`
  ADD PRIMARY KEY (`id_turma`);

--
-- Indexes for table `tb_turno`
--
ALTER TABLE `tb_turno`
  ADD PRIMARY KEY (`id_turno`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `tipoUser` (`tipoUser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_categoria`
--
ALTER TABLE `tb_categoria`
  MODIFY `id_categoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_comentario`
--
ALTER TABLE `tb_comentario`
  MODIFY `id_comentario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_disciplina`
--
ALTER TABLE `tb_disciplina`
  MODIFY `id_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_ensino`
--
ALTER TABLE `tb_ensino`
  MODIFY `id_ensino` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_perguntas`
--
ALTER TABLE `tb_perguntas`
  MODIFY `id_perguntas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_professor`
--
ALTER TABLE `tb_professor`
  MODIFY `id_professor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_prof_dis_turm`
--
ALTER TABLE `tb_prof_dis_turm`
  MODIFY `id_pdt` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_respostaprofessor`
--
ALTER TABLE `tb_respostaprofessor`
  MODIFY `id_resprof` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_respostas`
--
ALTER TABLE `tb_respostas`
  MODIFY `id_resposta` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_sedes`
--
ALTER TABLE `tb_sedes`
  MODIFY `id_sedes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_sede_turma_turno_serie_ensino`
--
ALTER TABLE `tb_sede_turma_turno_serie_ensino`
  MODIFY `id_sttse` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tb_series`
--
ALTER TABLE `tb_series`
  MODIFY `id_serie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_tipousers`
--
ALTER TABLE `tb_tipousers`
  MODIFY `id_tipousers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_turma`
--
ALTER TABLE `tb_turma`
  MODIFY `id_turma` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tb_turno`
--
ALTER TABLE `tb_turno`
  MODIFY `id_turno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `tb_comentario`
--
ALTER TABLE `tb_comentario`
  ADD CONSTRAINT `fk_categoria` FOREIGN KEY (`fk_categoria`) REFERENCES `tb_categoria` (`id_categoria`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sttsee` FOREIGN KEY (`fk_sttsee`) REFERENCES `tb_sede_turma_turno_serie_ensino` (`id_sttse`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `tb_perguntas`
--
ALTER TABLE `tb_perguntas`
  ADD CONSTRAINT `fk_categories` FOREIGN KEY (`fk_categories`) REFERENCES `tb_categoria` (`id_categoria`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tpensino` FOREIGN KEY (`fk_tpensino`) REFERENCES `tb_ensino` (`id_ensino`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `tb_prof_dis_turm`
--
ALTER TABLE `tb_prof_dis_turm`
  ADD CONSTRAINT `fk_disci` FOREIGN KEY (`fk_disci`) REFERENCES `tb_disciplina` (`id_disciplina`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prof` FOREIGN KEY (`fk_prof`) REFERENCES `tb_professor` (`id_professor`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sttse` FOREIGN KEY (`fk_sttse`) REFERENCES `tb_sede_turma_turno_serie_ensino` (`id_sttse`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `tb_respostas`
--
ALTER TABLE `tb_respostas`
  ADD CONSTRAINT `fk_pergunta` FOREIGN KEY (`fk_pergunta`) REFERENCES `tb_perguntas` (`id_perguntas`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sttseresp` FOREIGN KEY (`fk_sttseresp`) REFERENCES `tb_sede_turma_turno_serie_ensino` (`id_sttse`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `tb_sede_turma_turno_serie_ensino`
--
ALTER TABLE `tb_sede_turma_turno_serie_ensino`
  ADD CONSTRAINT `fk_ensino` FOREIGN KEY (`fk_ensino`) REFERENCES `tb_ensino` (`id_ensino`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sede` FOREIGN KEY (`fk_sede`) REFERENCES `tb_sedes` (`id_sedes`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_serie` FOREIGN KEY (`fk_serie`) REFERENCES `tb_series` (`id_serie`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_turma` FOREIGN KEY (`fk_turma`) REFERENCES `tb_turma` (`id_turma`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_turno` FOREIGN KEY (`fk_turno`) REFERENCES `tb_turno` (`id_turno`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `tipoUser` FOREIGN KEY (`tipoUser`) REFERENCES `tb_tipousers` (`id_tipousers`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
